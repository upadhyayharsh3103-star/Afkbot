#!/bin/bash
export DISPLAY=:1
LOGFILE="/home/nonbios/watchdog.log"
NHOME="/home/nonbios"

log() {
    # Cap log at 100KB
    if [ -f "$LOGFILE" ] && [ $(stat -c%s "$LOGFILE" 2>/dev/null || echo 0) -gt 102400 ]; then
        tail -20 "$LOGFILE" > "$LOGFILE.tmp" && mv "$LOGFILE.tmp" "$LOGFILE"
    fi
    echo "$(date) - $1" >> "$LOGFILE"
}

restart_vnc() {
    log "Restarting VNC"
    su - nonbios -c "vncserver -kill :1" 2>/dev/null
    sleep 2
    su - nonbios -c "vncserver :1 -geometry 1280x800 -depth 24 -localhost no" 2>/dev/null
    sleep 3
}

restart_tlauncher() {
    if ! pgrep -f "TLauncher.jar" > /dev/null; then
        log "Restarting TLauncher"
        su - nonbios -c "export DISPLAY=:1; setsid java -jar $NHOME/tlauncher/TLauncher.jar &>/dev/null &"
    fi
}

restart_autoclicker() {
    if ! pgrep -f "autoclicker.py" > /dev/null; then
        log "Restarting AutoClicker 1"
        su - nonbios -c "export DISPLAY=:1; setsid python3 $NHOME/autoclicker.py &>/dev/null &"
    fi
}

restart_autoclicker2() {
    if ! pgrep -f "autoclicker2.py" > /dev/null; then
        log "Restarting AutoClicker 2"
        su - nonbios -c "export DISPLAY=:1; setsid python3 $NHOME/autoclicker2.py &>/dev/null &"
    fi
}

restart_autoclicker3() {
    if ! pgrep -f "autoclicker3.py" > /dev/null; then
        log "Restarting AutoClicker 3"
        su - nonbios -c "export DISPLAY=:1; setsid python3 $NHOME/autoclicker3.py &>/dev/null &"
    fi
}
restart_autoclicker4() {
    if ! pgrep -f "autoclicker4.py" > /dev/null; then
        log "Restarting AutoClicker 4"
        su - nonbios -c "export DISPLAY=:1; setsid python3 $NHOME/autoclicker4.py &>/dev/null &"
    fi
}


apply_oom_protection() {
    for pid in $(pgrep -f "java|autoclicker|Xtigervnc"); do
        echo -1000 > /proc/$pid/oom_score_adj 2>/dev/null
    done
}

# Initial VNC check
if ! pgrep -x Xtigervnc > /dev/null; then
    restart_vnc
fi

while true; do
    if ! pgrep -x Xtigervnc > /dev/null; then
        restart_vnc
        sleep 3
    fi
    restart_autoclicker
    restart_autoclicker2
    restart_autoclicker3
    restart_autoclicker4
    restart_tlauncher
    apply_oom_protection
    sleep 10
done
