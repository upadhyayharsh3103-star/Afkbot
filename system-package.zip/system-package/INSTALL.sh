#!/bin/bash
set -e
echo "============================================================"
echo "  CARBON COPY INSTALLER - TLauncher + AutoClicker System"
echo "  One command = exact replica of the original setup"
echo "============================================================"
echo ""

NHOME="$HOME"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

# [1/9] Install dependencies
echo "[1/9] Installing dependencies..."
sudo apt-get update -qq
sudo apt-get install -y -qq tigervnc-standalone-server tigervnc-common xfce4 xfce4-goodies python3 python3-tk xdotool default-jre wget > /dev/null 2>&1
echo "      ✓ Dependencies installed"

# [2/9] Setup 8GB Swap (extra RAM)
echo "[2/9] Setting up 8GB Swap..."
if [ ! -f /swapfile ] || [ "$(stat -c%s /swapfile 2>/dev/null)" != "8589934592" ]; then
    sudo swapoff -a 2>/dev/null || true
    sudo rm -f /swapfile
    sudo fallocate -l 8G /swapfile
    sudo chmod 600 /swapfile
    sudo mkswap /swapfile > /dev/null
    sudo swapon /swapfile
    grep -q "/swapfile" /etc/fstab || echo "/swapfile none swap sw 0 0" | sudo tee -a /etc/fstab > /dev/null
fi
echo "      ✓ 8GB Swap active"

# [3/9] Setup VNC with password
echo "[3/9] Setting up VNC..."
mkdir -p ~/.vnc
cp vnc-config/passwd ~/.vnc/passwd
chmod 600 ~/.vnc/passwd
cp vnc-config/xstartup ~/.vnc/xstartup
chmod +x ~/.vnc/xstartup
# Kill existing VNC if any
vncserver -kill :1 2>/dev/null || true
sleep 1
vncserver :1 -geometry 1280x800 -depth 24 -localhost no 2>/dev/null
echo "      ✓ VNC running on port 5901 (password pre-configured)"

# [4/9] Install TLauncher
echo "[4/9] Installing TLauncher..."
mkdir -p ~/tlauncher
cp tlauncher/TLauncher.jar ~/tlauncher/
echo "      ✓ TLauncher installed"

# [5/9] Install AutoClickers
echo "[5/9] Installing AutoClickers..."
cp autoclicker.py ~/autoclicker.py
cp autoclicker2.py ~/autoclicker2.py
cp autoclicker3.py ~/autoclicker3.py
chmod +x ~/autoclicker*.py
echo "      ✓ 3 AutoClickers installed"

# [6/9] Install Watchdog (auto-restart crashed processes)
echo "[6/9] Installing Watchdog..."
cp watchdog.sh ~/watchdog.sh
chmod +x ~/watchdog.sh
sudo cp vnc-watchdog.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable vnc-watchdog > /dev/null 2>&1
sudo systemctl start vnc-watchdog
echo "      ✓ Watchdog active (auto-restarts TLauncher/AutoClickers/VNC)"

# [7/9] Setup OOM Protection (processes never killed)
echo "[7/9] Setting up OOM Protection..."
if [ -f oom-protect.sh ]; then
    sudo cp oom-protect.sh /usr/local/bin/oom-protect.sh
    sudo chmod +x /usr/local/bin/oom-protect.sh
fi
if [ -f oom-protect.service ]; then
    sudo cp oom-protect.service /etc/systemd/system/
    sudo systemctl daemon-reload
    sudo systemctl enable oom-protect > /dev/null 2>&1
    sudo systemctl start oom-protect
fi
# Immediate OOM protection
for pid in $(pgrep -f "java|autoclicker|Xtigervnc" 2>/dev/null); do
    echo -1000 | sudo tee /proc/$pid/oom_score_adj > /dev/null 2>&1
done
echo "      ✓ OOM Protection active (critical processes unkillable)"

# [8/9] Disable automatic reboot
echo "[8/9] Disabling automatic reboot..."
echo 'Unattended-Upgrade::Automatic-Reboot "false";' | sudo tee /etc/apt/apt.conf.d/99-no-reboot > /dev/null
echo 0 | sudo tee /proc/sys/vm/panic_on_oom > /dev/null
echo 1 | sudo tee /proc/sys/vm/overcommit_memory > /dev/null
echo "      ✓ Auto-reboot disabled"

# [9/9] Launch everything
echo "[9/9] Launching TLauncher + AutoClickers..."
sleep 2
export DISPLAY=:1
# Launch TLauncher
setsid java -jar ~/tlauncher/TLauncher.jar &>/dev/null &
sleep 3
# Launch AutoClickers
setsid python3 ~/autoclicker.py &>/dev/null &
sleep 1
setsid python3 ~/autoclicker2.py &>/dev/null &
sleep 1
setsid python3 ~/autoclicker3.py &>/dev/null &
sleep 2

# Apply OOM protection to new processes
for pid in $(pgrep -f "java|autoclicker|Xtigervnc" 2>/dev/null); do
    echo -1000 | sudo tee /proc/$pid/oom_score_adj > /dev/null 2>&1
done

echo ""
echo "============================================================"
echo "  ✓ INSTALLATION COMPLETE - EXACT CARBON COPY"
echo "============================================================"
echo ""
echo "  VNC:          Port 5901 (password pre-set)"
echo "  TLauncher:    Running"
echo "  AutoClicker:  3 instances running"
echo "  Watchdog:     Active (auto-heals crashes)"
echo "  OOM Protect:  Active (never killed)"
echo "  Swap:         8GB (extra RAM)"
echo "  Auto-Reboot:  Disabled"
echo ""
echo "  Connect via VNC viewer to <your-ip>:5901"
echo ""
echo "============================================================"
