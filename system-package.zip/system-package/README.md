# TLauncher + AutoClicker + Self-Healing System

## Features
- **TLauncher** - Minecraft launcher
- **3x AutoClickers** with:
  - Click interval in seconds (not milliseconds)
  - Left and Right click support
  - Set location via mouse with 5-second timer
  - Random location mode
- **Self-Healing Watchdog** - Monitors every 10 seconds, auto-restarts crashed processes
- **OOM Protection** - All critical processes protected from being killed
- **8GB Swap** - Prevents memory exhaustion
- **Systemd Services** - Everything starts on boot

## Installation
```bash
chmod +x INSTALL.sh
./INSTALL.sh
```

## Requirements
- Ubuntu 20.04+ / Debian-based Linux
- At least 4GB RAM (8GB swap will be added)
- Java Runtime (installed automatically)
- Python 3 with tkinter (installed automatically)

## Access
- VNC: Connect to port 5901
- All processes auto-start and self-heal

## Files
- autoclicker.py - Main AutoClicker
- autoclicker2.py - AutoClicker instance 2
- autoclicker3.py - AutoClicker instance 3
- watchdog.sh - Self-healing watchdog script
- vnc-watchdog.service - Systemd watchdog service
- oom-protect.service - OOM protection service
- oom-protect.sh - OOM protection script
- INSTALL.sh - One-click installer
- tlauncher/ - TLauncher files
