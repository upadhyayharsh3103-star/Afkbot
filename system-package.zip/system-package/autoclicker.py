#!/usr/bin/env python3
import tkinter as tk
import subprocess
import threading
import time
import random
import sys
import os

class AutoClicker:
    def __init__(self):
        try:
            self.root = tk.Tk()
            self.root.title("AutoClicker")
            self.root.geometry("350x400")
            self.root.resizable(False, False)
            self.root.protocol("WM_DELETE_WINDOW", self.on_close)
            
            self.running = False
            self.click_x = None
            self.click_y = None
            self.interval = 5
            self.click_type = "left"
            self.random_mode = False
            self.setting_location = False
            self.alive = True
            
            self.build_ui()
        except Exception as e:
            self.log_error(f"Init error: {e}")
            sys.exit(1)
        
    def log_error(self, msg):
        with open(os.path.expanduser("~/autoclicker.log"), "a") as f:
            f.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')} - {msg}\n")

    def on_close(self):
        self.alive = False
        self.running = False
        time.sleep(0.5)
        self.root.destroy()

    def build_ui(self):
        # Interval
        frame1 = tk.LabelFrame(self.root, text="Click Interval (seconds)", padx=10, pady=5)
        frame1.pack(fill="x", padx=10, pady=5)
        
        self.interval_var = tk.StringVar(value="5")
        self.interval_entry = tk.Entry(frame1, textvariable=self.interval_var, font=("Arial", 14), width=10)
        self.interval_entry.pack(pady=5)
        
        # Click Type
        frame2 = tk.LabelFrame(self.root, text="Click Type", padx=10, pady=5)
        frame2.pack(fill="x", padx=10, pady=5)
        
        self.click_type_var = tk.StringVar(value="left")
        tk.Radiobutton(frame2, text="Left Click", variable=self.click_type_var, value="left", font=("Arial", 11)).pack(side="left", padx=20)
        tk.Radiobutton(frame2, text="Right Click", variable=self.click_type_var, value="right", font=("Arial", 11)).pack(side="left", padx=20)
        
        # Location
        frame3 = tk.LabelFrame(self.root, text="Click Location", padx=10, pady=5)
        frame3.pack(fill="x", padx=10, pady=5)
        
        self.loc_label = tk.Label(frame3, text="Not Set", font=("Arial", 11), fg="red")
        self.loc_label.pack(pady=2)
        
        self.set_loc_btn = tk.Button(frame3, text="Set Location (5s timer)", command=self.start_set_location, font=("Arial", 10))
        self.set_loc_btn.pack(pady=3)
        
        self.timer_label = tk.Label(frame3, text="", font=("Arial", 12, "bold"), fg="blue")
        self.timer_label.pack(pady=2)
        
        # Random Mode
        frame4 = tk.LabelFrame(self.root, text="Random Location Mode", padx=10, pady=5)
        frame4.pack(fill="x", padx=10, pady=5)
        
        self.random_var = tk.BooleanVar(value=False)
        tk.Checkbutton(frame4, text="Enable Random Location (moves every 5s)", variable=self.random_var, font=("Arial", 10)).pack(pady=3)
        
        # Controls
        frame5 = tk.Frame(self.root, padx=10, pady=10)
        frame5.pack(fill="x")
        
        self.start_btn = tk.Button(frame5, text="START", command=self.start_clicking, font=("Arial", 12, "bold"), bg="green", fg="white", width=12)
        self.start_btn.pack(side="left", padx=15)
        
        self.stop_btn = tk.Button(frame5, text="STOP", command=self.stop_clicking, font=("Arial", 12, "bold"), bg="red", fg="white", width=12, state="disabled")
        self.stop_btn.pack(side="right", padx=15)
        
        # Status
        self.status_label = tk.Label(self.root, text="Status: Stopped", font=("Arial", 10))
        self.status_label.pack(pady=5)
        
    def start_set_location(self):
        self.setting_location = True
        self.set_loc_btn.config(state="disabled")
        t = threading.Thread(target=self.countdown_set_location, daemon=True)
        t.start()
        
    def countdown_set_location(self):
        try:
            for i in range(5, 0, -1):
                if not self.alive:
                    return
                self.root.after(0, lambda v=i: self.timer_label.config(text=f"Move mouse now... {v}s"))
                time.sleep(1)
            # Capture mouse position
            result = subprocess.run(["xdotool", "getmouselocation"], capture_output=True, text=True, timeout=5)
            parts = result.stdout.strip().split()
            self.click_x = int(parts[0].split(":")[1])
            self.click_y = int(parts[1].split(":")[1])
            self.root.after(0, lambda: self.timer_label.config(text=""))
            self.root.after(0, lambda: self.loc_label.config(text=f"Location: ({self.click_x}, {self.click_y})", fg="green"))
            self.root.after(0, lambda: self.set_loc_btn.config(state="normal"))
            self.setting_location = False
        except Exception as e:
            self.log_error(f"Set location error: {e}")
            self.root.after(0, lambda: self.set_loc_btn.config(state="normal"))
            self.root.after(0, lambda: self.timer_label.config(text="Error! Try again"))
            self.setting_location = False
        
    def start_clicking(self):
        try:
            self.interval = int(self.interval_var.get())
        except ValueError:
            self.interval = 5
            
        if not self.random_var.get() and self.click_x is None:
            self.status_label.config(text="Status: Set a location first!", fg="red")
            return
            
        self.running = True
        self.start_btn.config(state="disabled")
        self.stop_btn.config(state="normal")
        self.status_label.config(text="Status: Running", fg="green")
        t = threading.Thread(target=self.click_loop, daemon=True)
        t.start()
        
    def stop_clicking(self):
        self.running = False
        self.start_btn.config(state="normal")
        self.stop_btn.config(state="disabled")
        self.status_label.config(text="Status: Stopped", fg="black")
        
    def click_loop(self):
        while self.running and self.alive:
            try:
                if self.random_var.get():
                    x = random.randint(100, 1180)
                    y = random.randint(100, 700)
                else:
                    x = self.click_x
                    y = self.click_y
                
                btn = "1" if self.click_type_var.get() == "left" else "3"
                subprocess.run(["xdotool", "mousemove", str(x), str(y)], timeout=5)
                subprocess.run(["xdotool", "click", btn], timeout=5)
                
                # Wait for interval (check every second if still running)
                for i in range(self.interval):
                    if not self.running or not self.alive:
                        return
                    time.sleep(1)
            except Exception as e:
                self.log_error(f"Click loop error: {e}")
                time.sleep(1)
    
    def run(self):
        try:
            self.root.mainloop()
        except Exception as e:
            self.log_error(f"Mainloop error: {e}")

if __name__ == "__main__":
    try:
        app = AutoClicker()
        app.run()
    except Exception as e:
        with open(os.path.expanduser("~/autoclicker.log"), "a") as f:
            f.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')} - Fatal: {e}\n")
        sys.exit(1)
