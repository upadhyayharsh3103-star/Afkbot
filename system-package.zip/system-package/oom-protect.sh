#!/bin/bash
while true; do
    for pid in $(pgrep -f "java|autoclicker|Xtigervnc"); do
        echo -1000 > /proc/$pid/oom_score_adj 2>/dev/null
    done
    sleep 15
done
