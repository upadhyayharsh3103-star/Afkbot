#!/bin/bash
# Wrapper: cap TLauncher child JVM to 256MB
ARGS=()
for arg in "$@"; do
    if [[ "$arg" == -Xmx* ]]; then
        ARGS+=("-Xmx256m")
    else
        ARGS+=("$arg")
    fi
done
exec "$(dirname "$0")/java.real" "${ARGS[@]}"
