#!/bin/bash
set -e
echo "============================================================"
echo "  AFKBOT INSTALLER - Lean Minecraft AFK Setup"
echo "  Openbox + TLauncher (256MB) + Minecraft (512MB)"
echo "============================================================"
echo ""

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

# [1/8] Install dependencies
echo "[1/8] Installing dependencies..."
sudo apt-get update -qq
sudo apt-get install -y -qq tigervnc-standalone-server tigervnc-common openbox hsetroot python3 python3-tk xdotool default-jre cpulimit > /dev/null 2>&1
echo "      ✓ Dependencies installed (Openbox, VNC, Python, Java)"

# [2/8] Setup 4GB Swap
echo "[2/8] Setting up 4GB Swap..."
if [ ! -f /swapfile ] || [ "$(stat -c%s /swapfile 2>/dev/null)" != "4294967296" ]; then
    sudo swapoff -a 2>/dev/null || true
    sudo rm -f /swapfile
    sudo fallocate -l 4G /swapfile
    sudo chmod 600 /swapfile
    sudo mkswap /swapfile > /dev/null
    sudo swapon /swapfile
    grep -q "/swapfile" /etc/fstab || echo "/swapfile none swap sw 0 0" | sudo tee -a /etc/fstab > /dev/null
fi
echo "      ✓ 4GB Swap active"

# [3/8] Setup VNC with Openbox
echo "[3/8] Setting up VNC with Openbox..."
mkdir -p ~/.vnc
cp vnc-config/passwd ~/.vnc/passwd
chmod 600 ~/.vnc/passwd
cp vnc-config/xstartup ~/.vnc/xstartup
chmod +x ~/.vnc/xstartup
vncserver -kill :1 2>/dev/null || true
sleep 1
vncserver :1 -geometry 1280x800 -depth 24 -localhost no 2>/dev/null
sleep 2
export DISPLAY=:1
hsetroot -solid "#2d2d2d" 2>/dev/null || xsetroot -solid "#2d2d2d" 2>/dev/null
echo "      ✓ VNC running on port 5901 (Openbox desktop)"

# [4/8] Install TLauncher with 256MB cap
echo "[4/8] Installing TLauncher..."
mkdir -p ~/tlauncher
cp tlauncher/TLauncher.jar ~/tlauncher/
# Setup java wrapper to cap TLauncher child JVM at 256MB
if [ -f configs/java-wrapper.sh ] && [ -f configs/java.real ]; then
    JVMDIR="$HOME/.tlauncher/jvms/jre1.8.0_281/bin"
    mkdir -p "$JVMDIR"
    cp configs/java.real "$JVMDIR/java.real"
    cp configs/java-wrapper.sh "$JVMDIR/java"
    chmod +x "$JVMDIR/java" "$JVMDIR/java.real"
fi
# Set Minecraft heap to 512MB
if [ -f configs/tlauncher-2.0.properties ]; then
    mkdir -p ~/.tlauncher
    cp configs/tlauncher-2.0.properties ~/.tlauncher/
fi
echo "      ✓ TLauncher installed (launcher=256MB, Minecraft=512MB)"

# [5/8] Install AutoClickers (2x, 60-second interval)
echo "[5/8] Installing AutoClickers..."
cp autoclicker.py ~/autoclicker.py
cp autoclicker2.py ~/autoclicker2.py
chmod +x ~/autoclicker*.py
echo "      ✓ 2 AutoClickers installed (Keep Alive + Work, 60s default)"

# [6/8] Disable automatic reboot
echo "[6/8] Disabling automatic reboot..."
sudo cp 99-no-reboot /etc/apt/apt.conf.d/99-no-reboot
echo 0 | sudo tee /proc/sys/vm/panic_on_oom > /dev/null
echo 1 | sudo tee /proc/sys/vm/overcommit_memory > /dev/null
echo "      ✓ Auto-reboot disabled"

# [7/8] Launch TLauncher + AutoClickers
echo "[7/8] Launching TLauncher + AutoClickers..."
export DISPLAY=:1
setsid java -Xmx256m -jar ~/tlauncher/TLauncher.jar &>/dev/null &
sleep 3
setsid python3 ~/autoclicker.py &>/dev/null &
sleep 1
setsid python3 ~/autoclicker2.py &>/dev/null &
sleep 2
echo "      ✓ TLauncher and 2 AutoClickers running"

# [8/8] Setup CPU cap for Minecraft (apply after game launches)
echo "[8/8] Creating Minecraft CPU cap script..."
cat > ~/cap-minecraft-cpu.sh << 'CAPEOF'
#!/bin/bash
# Run this AFTER Minecraft finishes loading
MC_PID=$(pgrep -f "java-runtime-delta")
if [ -z "$MC_PID" ]; then
    echo "Minecraft not running yet. Launch the game first, then run this."
    exit 1
fi
echo "+cpu" | sudo tee /sys/fs/cgroup/cgroup.subtree_control > /dev/null
sudo mkdir -p /sys/fs/cgroup/minecraft
echo "80000 100000" | sudo tee /sys/fs/cgroup/minecraft/cpu.max > /dev/null
echo $MC_PID | sudo tee /sys/fs/cgroup/minecraft/cgroup.procs > /dev/null
echo "✓ Minecraft (PID $MC_PID) capped at 80% CPU via cgroups v2"
CAPEOF
chmod +x ~/cap-minecraft-cpu.sh
echo "      ✓ Run ~/cap-minecraft-cpu.sh after Minecraft loads"

echo ""
echo "============================================================"
echo "  ✓ INSTALLATION COMPLETE - LEAN AFK SETUP"
echo "============================================================"
echo ""
echo "  VNC:          Port 5901 (password pre-set)"
echo "  Desktop:      Openbox (lightweight)"
echo "  TLauncher:    Running (256MB cap)"
echo "  Minecraft:    512MB heap (set in properties)"
echo "  AutoClicker:  2 instances (60s interval)"
echo "  Swap:         4GB"
echo "  Auto-Reboot:  Disabled"
echo "  CPU Cap:      Run ~/cap-minecraft-cpu.sh after game loads"
echo ""
echo "  Connect via VNC viewer to <your-ip>:5901"
echo ""
echo "============================================================"
