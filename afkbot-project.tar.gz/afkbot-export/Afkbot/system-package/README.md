# Afkbot - Lean Minecraft AFK Setup

## Features
- **Openbox** - Lightweight window manager (replaces XFCE)
- **TLauncher** - Minecraft launcher capped at 256MB via java wrapper
- **Minecraft** - Heap capped at 512MB
- **2x AutoClickers** with:
  - Keep Alive + Work (labeled)
  - 60-second default interval
  - Click interval in seconds
  - Left and Right click support
  - Set location via mouse with 5-second timer
  - Random location mode
- **CPU Cap** - Minecraft limited to 80% via cgroups v2
- **4GB Swap** - Safety net for memory
- **No Watchdog/OOM** - Removed to reduce overhead
- **Auto-Reboot Disabled**

## Installation
```bash
chmod +x INSTALL.sh
./INSTALL.sh
```
After Minecraft loads, run:
```bash
~/cap-minecraft-cpu.sh
```

## Requirements
- Ubuntu 20.04+ / Debian-based Linux
- At least 2GB RAM (4GB swap added)
- Java Runtime (installed automatically)
- Python 3 with tkinter (installed automatically)

## Access
- VNC: Connect to port 5901

## Resource Limits
| Component      | Limit  | Method                |
|----------------|--------|-----------------------|
| TLauncher JVM  | 256MB  | Java wrapper script   |
| Minecraft      | 512MB  | TLauncher properties  |
| Minecraft CPU  | 80%    | cgroups v2            |
| Desktop        | Light  | Openbox (not XFCE)    |
| Swap           | 4GB    | /swapfile             |
| Autoclickers   | 60s    | 2 instances           |
| Auto-reboot    | Off    | apt config            |

## Files
- `autoclicker.py` - Keep Alive AutoClicker (60s)
- `autoclicker2.py` - Work AutoClicker (60s)
- `configs/java-wrapper.sh` - TLauncher 256MB cap wrapper
- `configs/java.real` - Original Java binary
- `configs/tlauncher-2.0.properties` - Minecraft 512MB config
- `99-no-reboot` - Disable automatic reboot
- `vnc-config/` - VNC password + Openbox xstartup
- `tlauncher/` - TLauncher JAR
- `INSTALL.sh` - One-click installer
