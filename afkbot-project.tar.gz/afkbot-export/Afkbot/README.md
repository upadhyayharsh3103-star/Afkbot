# Afkbot

Lean Minecraft AFK Bot setup — lightweight desktop, memory-capped launcher, CPU-throttled game, and two autoclickers.

## Quick Start
```bash
cd system-package
chmod +x INSTALL.sh
./INSTALL.sh
```
After Minecraft loads:
```bash
~/cap-minecraft-cpu.sh
```

See `system-package/README.md` for full details.
